package com.example.aditya.quizapp1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by PC on 01-07-2017.
 */
public class DataBaseHelper extends SQLiteOpenHelper{
    private static final int DATABASE_VERSION = 1;
    // Database Name
    private static final String DATABASE_NAME ="Quiz";
    // tasks table name
    private static final String TABLE_QUEST = "quest";
    // tasks Table Columns names
    private static final String KEY_ID ="id";
    private static final String KEY_QUES ="question";
    private static final String KEY_ANSWER ="answer"; //correct option
    private static final String KEY_OPTA= "opta"; //option a
    private static final String KEY_OPTB="optb"; //option b
    private static final String KEY_OPTC= "optc"; //option c
    private SQLiteDatabase dbase;

    public DataBaseHelper(final Context context) {

        super(context, Environment.getExternalStorageDirectory() +
                File.separator + "quiz" +
                File.separator + TABLE_QUEST,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        dbase=db;
        String sql = "CREATE TABLE IF NOT EXISTS " + TABLE_QUEST + "( "
        + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + KEY_QUES
                + " TEXT, " + KEY_ANSWER+ " TEXT, "+KEY_OPTA +" TEXT, "
        +KEY_OPTB +" TEXT, "+KEY_OPTC+" TEXT)";
        db.execSQL(sql);
        addQuestions();
//db.close();
    }
    private void addQuestions()
    {
        Question q1=new Question("Android discovered in ","2005","2005","2011","2016");
        this.addQuestion(q1);
        Question q2=new Question("Which Corporation brought Android?","Google","Google","Apple","Amazon");
        this.addQuestion(q2);
        Question q3=new Question("WWW stands for","world wide web","world web writing","world wide web","no answer" );
        this.addQuestion(q3);
        Question q4=new Question("Which country’s team has won the 2017 Asian Team Snooker Championship?","India","Japan","China","India");
        this.addQuestion(q4);
        Question q5=new Question("Who is the newly appointed Chief Election Commissioner (CEC)","AK Jyoti","AK Jyoti","H S Brahma","V S Sampath");
        this.addQuestion(q5);
        Question q6=new Question("Full form of URL is","Uniform Resource Locator","Uniform Resource Locator","Uniform Registered Link","Unified Resource Link");
        this.addQuestion(q6);
        Question q7=new Question("Most Centuries in odi's while chasing is made by?","Virat Kohli","Virat Kohli","Sachin Tendulkar","AB Divilliers");
        this.addQuestion(q7);
        Question q8=new Question("Most Grandslam winner male in tennis?","Roger Federer","Pete Sampras","Roger Federer","Rafa Nadal");
        this.addQuestion(q8);
        Question q9=new Question("Hybridization is","cross-fertilization between two varieties","cross-fertilization between two varieties","decayed vegetable matter","a process of tilling the land");
        this.addQuestion(q9);
        Question q10=new Question("India's first atomic power station was set up at","Tarapur","Trombay","Tarapur","Bombay");
        this.addQuestion(q10);
        Question q11=new Question("How many times has Brazil won the World Cup Football Championship?","5","5","4","2");
        this.addQuestion(q11);
        Question q12=new Question("If speed of rotation of the earth increases, weight of the body","increases","increases","decreases","Remains same");
        this.addQuestion(q12);
        Question q13=new Question("Google was founded in","1998","1998","1999","1997");
        this.addQuestion(q13);
        Question q14=new Question("All Radioactive substances are Manmade?","False","False","True","Not known");
        this.addQuestion(q14);
        Question q15=new Question("Full form of URL is","Uniform Resource Locator","Uniform Resource Locator","Uniform Registered Link","Unified Resource Link");
        this.addQuestion(q15);
        Question q16=new Question("Computer having more than one processor is","Multiprocessor","Multitasker","Multimanager","Multiprocessor");
        this.addQuestion(q16);
        Question q17=new Question("India's first nuclear blast at Pokhran in Rajasthan took place in","1974","1964","1976","1974");
        this.addQuestion(q17);
        Question q18=new Question("India has largest deposits of?","mica","silver","mica","gold");
        this.addQuestion(q18);
        Question q19=new Question("RAM is?","Primary Memory","Secondary Memory","Primary Memory","Tertiary Memory");
        this.addQuestion(q19);
        Question q20=new Question("Which kind of waves are used to make and receive cellphone calls?","Radio Waves","Radio Waves","Infrared waves","UV rays");
        this.addQuestion(q20);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
// Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_QUEST);
// Create tables again
        onCreate(db);
    }

    // Adding new question
    public void addQuestion(Question quest) {
//SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_QUES, quest.getQuestion());
        values.put(KEY_ANSWER, quest.getAnswer());
        values.put(KEY_OPTA, quest.getOptionA());
        values.put(KEY_OPTB, quest.getOptionB());
        values.put(KEY_OPTC, quest.getOptionC());
// Inserting Row
        dbase.insert(TABLE_QUEST, null, values);
    }

    public List<Question> getAllQuestions() {
        List<Question> quesList = new ArrayList<Question>();
// Select All Query
        String selectQuery = "SELECT * FROM " + TABLE_QUEST;
        dbase=this.getReadableDatabase();
        Cursor cursor = dbase.rawQuery(selectQuery, null);
// looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Question quest = new Question();
                quest.setId(cursor.getInt(0));
                quest.setQuestion(cursor.getString(1));
                quest.setAnswer(cursor.getString(2));
                quest.setOptionA(cursor.getString(3));
                quest.setOptionB(cursor.getString(4));
                quest.setOptionC(cursor.getString(5));
                quesList.add(quest);
            } while (cursor.moveToNext());
        }
// return quest list
        return quesList;
    }
    public int rowcount()
    {
        int row=0;
        String selectQuery = "SELECT * FROM " + TABLE_QUEST;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        row=cursor.getCount();
        return row;
    }
}


