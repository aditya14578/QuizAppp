package com.example.aditya.quizapp1;

/**
 * Created by PC on 01-07-2017.
 */
public class Question {
    private int Id;
    private String question;
    private String answer;
    private String optionA;
    private String optionB;
    private String optionC;

    public Question(){
        Id=0;
        question="";
        answer="";
        optionA="";
        optionB="";
        optionC="";
    }
    public Question(String Question, String Answer, String OptionA, String OptionB, String OptionC){

        question=Question;
        answer=Answer;
        optionA=OptionA;
        optionB=OptionB;
        optionC=OptionC;

    }

    public String getOptionA() {
        return optionA;
    }

    public void setOptionA(String optionA) {
        this.optionA = optionA;
    }

    public String getOptionB() {
        return optionB;
    }
    public void setOptionB(String optionB) {
        this.optionB = optionB;
    }

    public String getOptionC() {
        return optionC;
    }

    public void setOptionC(String optionC) {
        this.optionC = optionC;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }
    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }
}
