package com.example.aditya.quizapp1;

import android.app.Activity;

/**
 * Created by PC on 08-07-2017.
 */
public class answ extends Activity {

}
