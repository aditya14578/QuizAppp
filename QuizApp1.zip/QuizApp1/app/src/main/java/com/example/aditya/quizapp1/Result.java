
package com.example.aditya.quizapp1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;

    public class Result extends Activity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_result);

            /*RatingBar ratingBar = (RatingBar) findViewById(R.id.ratingBar);*/
            TextView textView = (TextView) findViewById(R.id.textView);
           //ratingBar.setNumStars(7);
            //ratingBar.setStepSize(0.5f);

            Bundle b = getIntent().getExtras();
            int score = b.getInt("score");

           // ratingBar.setRating(score);

           if(score<5)
               textView.setText("You got "+score+"\nYour Performance is not good");
            else if(score>=5&&score<=10)
               textView.setText("You got "+score+"\nperformance is below average");
            else if(score>10&&score<=15)
               textView.setText("Your performance is good! work hard --Your score is"+score);
            else if(score>15)
               textView.setText("Excellent you got"+score);


        }

    }
