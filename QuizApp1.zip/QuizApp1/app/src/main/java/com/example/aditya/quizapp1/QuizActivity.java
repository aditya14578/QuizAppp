package com.example.aditya.quizapp1;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.List;

/**
 * Created by PC on 01-07-2017.
 */
public class QuizActivity extends Activity {

    List<Question> questionList;
    int score=0;
    int questionId=0;
    Question checkquestion;
    SQLiteDatabase db;
    TextView tvQuestion;
    RadioButton OptionA;
    RadioButton OptionB;
    RadioButton OptionC;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        DataBaseHelper dbHelper = new DataBaseHelper(this);
        questionList = dbHelper.getAllQuestions();
        checkquestion = questionList.get(questionId);
        tvQuestion = (TextView) findViewById(R.id.tvQuestion);
        //answer=(RadioButton)findViewById(R.id.answer);
        OptionA = (RadioButton) findViewById(R.id.OptionA);
        OptionB = (RadioButton) findViewById(R.id.OptionB);
        OptionC = (RadioButton) findViewById(R.id.OptionC);
        ImageButton imageButton = (ImageButton) findViewById(R.id.imageBtn);
        setQuestionView();
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RadioGroup radioGroup = (RadioGroup) findViewById(R.id.radio);
                RadioButton answer = (RadioButton) findViewById(radioGroup.getCheckedRadioButtonId());
                Log.d("yourans", checkquestion.getAnswer() + " " + answer.getText());
                if (checkquestion.getAnswer().equals(answer.getText())) {
                    score++;
                    Log.d("score", "Your score" + score);
                }
                if (questionId < 20) {
                    checkquestion = questionList.get(questionId);
                    setQuestionView();
                } else {
                    Intent intent = new Intent(QuizActivity.this, Result.class);
                    Bundle b = new Bundle();
                    b.putInt("score", score); //Your score
                    intent.putExtras(b); //Put your score to your next Intent
                    startActivity(intent);
                    finish();
                }
            }

        });
    }
    private void setQuestionView()
    {
        tvQuestion.setText(checkquestion.getQuestion());
        OptionA.setText(checkquestion.getOptionA());
        OptionB.setText(checkquestion.getOptionB());
        OptionC.setText(checkquestion.getOptionC());
        questionId++;
    }
}
